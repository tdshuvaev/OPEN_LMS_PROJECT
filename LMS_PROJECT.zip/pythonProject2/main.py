import pygame
import random
import sqlite3
import os

pygame.init()

WIDTH, HEIGHT = 300, 600
TILE_SIZE = 30
GRID_WIDTH, GRID_HEIGHT = WIDTH // TILE_SIZE, HEIGHT // TILE_SIZE

COLORS = {
    "magenta": "magenta.png",
    "red": "red.png",
    "blue": "blue.png",
    "yellow": "yellow.png",
    "green": "green.png",
    "cyan": "cyan.png",
    "orange": "orange.png",
}

SHAPES = {
    "I": [(0, 0), (0, -1), (0, 1), (0, 2)],
    "O": [(0, 0), (0, 1), (1, 0), (1, 1)],
    "T": [(0, 0), (-1, 0), (1, 0), (0, 1)],
    "S": [(0, 0), (0, 1), (-1, 1), (-1, 2)],
    "Z": [(0, 0), (0, 1), (1, 1), (1, 2)],
    "L": [(0, 0), (0, -1), (0, 1), (1, -1)],
    "J": [(0, 0), (0, -1), (0, 1), (-1, -1)],
}

SPRITES = {color: pygame.image.load(sprite) for color, sprite in COLORS.items()}

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tetris")
clock = pygame.time.Clock()

background = pygame.image.load("background.png")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

font = pygame.font.SysFont("Arial", 24)

pygame.mixer.music.load("tetris_music.mp3")


def draw_background_pattern(surface=None):
    if surface is None:
        surface = screen
    pattern_color = (20, 20, 20)
    line_color = (30, 30, 30)
    step = 40

    width, height = surface.get_size()

    for x in range(0, width, step):
        pygame.draw.line(surface, line_color, (x, 0), (x, height), 1)

    for y in range(0, height, step):
        pygame.draw.line(surface, line_color, (0, y), (width, y), 1)

    for x in range(0, width, step):
        for y in range(0, height, step):
            pygame.draw.circle(surface, pattern_color, (x, y), 2)


class Button:
    def __init__(self, x, y, width, height, text, color, hover_color, radius=10):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.is_hovered = False
        self.radius = radius

    def draw(self, screen):
        if self.is_hovered:
            pygame.draw.rect(screen, self.hover_color, self.rect, border_radius=self.radius)
        else:
            pygame.draw.rect(screen, self.color, self.rect, border_radius=self.radius)
        text_surface = font.render(self.text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def check_hover(self, mouse_pos):
        self.is_hovered = self.rect.collidepoint(mouse_pos)

    def is_clicked(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)


def show_rules():
    rules_width = 500
    rules_height = 600
    rules_screen = pygame.display.set_mode((rules_width, rules_height))
    pygame.display.set_caption("Правила игры")
    rules_screen.fill((0, 0, 0))
    rules = [
        "Правила игры:",
        "1. Фигуры падают вниз.",
        "2. Управляйте фигурами:",
        "- Влево: ←",
        "- Вправо: →",
        "- Вращение: ↑",
        "- Ускорение: ↓",
        "3. Заполните линию, чтобы она исчезла.",
        "4. Игра заканчивается, если фигуры",
        "   достигают верха поля.",
        "Нажмите любую клавишу, чтобы вернуться."
    ]
    y_offset = 50
    for line in rules:
        text_surface = font.render(line, True, (255, 255, 255))
        rules_screen.blit(text_surface, (10, y_offset))
        y_offset += 30
    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False
    pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tetris")


def get_player_name():
    name = ""
    input_active = True
    while input_active:
        screen.fill((0, 0, 0))
        draw_background_pattern()
        text_surface = font.render("Введите ваше имя:", True, (255, 255, 255))
        screen.blit(text_surface, (10, HEIGHT // 2 - 50))
        name_surface = font.render(name, True, (255, 255, 255))
        screen.blit(name_surface, (10, HEIGHT // 2))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return ""
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    input_active = False
                elif event.key == pygame.K_BACKSPACE:
                    name = name[:-1]
                else:
                    name += event.unicode
    return name


def create_database():
    if not os.path.exists("tetris_records.db"):
        conn = sqlite3.connect("tetris_records.db")
        c = conn.cursor()
        c.execute("CREATE TABLE records (name TEXT, score INTEGER)")
        conn.commit()
        conn.close()


def save_record(name, score):
    conn = sqlite3.connect("tetris_records.db")
    c = conn.cursor()
    c.execute("INSERT INTO records (name, score) VALUES (?, ?)", (name, score))
    conn.commit()
    conn.close()


def show_records():
    screen.fill((0, 0, 0))
    draw_background_pattern()
    conn = sqlite3.connect("tetris_records.db")
    c = conn.cursor()
    c.execute("SELECT name, score FROM records ORDER BY score DESC LIMIT 10")
    records = c.fetchall()
    conn.close()
    y_offset = 50
    text_surface = font.render("Рекорды св. режима:", True, (255, 255, 255))
    screen.blit(text_surface, (10, y_offset))
    y_offset += 30
    for record in records:
        text_surface = font.render(f"{record[0]}: {record[1]}", True, (255, 255, 255))
        screen.blit(text_surface, (10, y_offset))
        y_offset += 30
    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False


def main_menu():
    start_button = Button(WIDTH // 2 - 75, HEIGHT // 2 - 100, 150, 50, "Начать игру", (0, 128, 0), (0, 255, 0),
                          radius=15)
    rules_button = Button(WIDTH // 2 - 75, HEIGHT // 2 - 20, 150, 50, "Правила", (128, 0, 0), (255, 0, 0), radius=15)
    records_button = Button(WIDTH // 2 - 75, HEIGHT // 2 + 60, 150, 50, "Рекорды", (0, 0, 128), (0, 0, 255), radius=15)

    while True:
        screen.blit(background, (0, 0))
        draw_background_pattern()
        start_button.draw(screen)
        rules_button.draw(screen)
        records_button.draw(screen)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEMOTION:
                mouse_pos = pygame.mouse.get_pos()
                start_button.check_hover(mouse_pos)
                rules_button.check_hover(mouse_pos)
                records_button.check_hover(mouse_pos)
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if start_button.is_clicked(mouse_pos):
                    return "start"
                if rules_button.is_clicked(mouse_pos):
                    show_rules()
                if records_button.is_clicked(mouse_pos):
                    show_records()


class Block:
    def __init__(self, shape, color):
        self.shape = SHAPES[shape]
        self.color = color
        self.x = GRID_WIDTH // 2
        self.y = 0

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def rotate(self):
        self.shape = [(-y, x) for x, y in self.shape]

    def get_positions(self):
        return [(self.x + x, self.y + y) for x, y in self.shape]

    def draw(self):
        for x, y in self.get_positions():
            if y >= 0:
                screen.blit(SPRITES[self.color], (x * TILE_SIZE, y * TILE_SIZE))


class Tetris:
    def __init__(self, level=None):
        self.grid = [[None for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
        self.current_block = self.new_block()
        self.running = True
        self.score = 0
        self.drop_timer = 0
        self.level = level
        self.level_goal = {1: 100, 2: 200, 3: 300}.get(level, None)

    def new_block(self):
        shape = random.choice(list(SHAPES.keys()))
        color = random.choice(list(COLORS.keys()))
        return Block(shape, color)

    def is_valid_position(self, block):
        for x, y in block.get_positions():
            if x < 0 or x >= GRID_WIDTH or y >= GRID_HEIGHT or (y >= 0 and self.grid[y][x] is not None):
                return False
        return True

    def place_block(self, block):
        for x, y in block.get_positions():
            if y >= 0:
                self.grid[y][x] = block.color
        self.score += len(block.shape)

    def clear_lines(self):
        cleared_lines = 0
        new_grid = [[None for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
        yi = GRID_HEIGHT - 1
        for y in range(GRID_HEIGHT - 1, -1, -1):
            if None in self.grid[y]:
                new_grid[yi] = self.grid[y]
                yi -= 1
            else:
                cleared_lines += 1
        self.grid = new_grid
        self.score += cleared_lines * 10

    def draw_grid(self):
        for y in range(GRID_HEIGHT):
            for x in range(GRID_WIDTH):
                rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                pygame.draw.rect(screen, (50, 50, 50), rect, 1)
                if self.grid[y][x]:
                    screen.blit(SPRITES[self.grid[y][x]], (x * TILE_SIZE, y * TILE_SIZE))

    def update(self):
        self.drop_timer += 1
        if self.drop_timer >= 20:
            self.drop_timer = 0
            self.current_block.move(0, 1)
            if not self.is_valid_position(self.current_block):
                self.current_block.move(0, -1)
                self.place_block(self.current_block)
                self.clear_lines()
                self.current_block = self.new_block()
                if not self.is_valid_position(self.current_block):
                    self.running = False

    def draw(self):
        screen.fill((0, 0, 0))
        draw_background_pattern()
        self.draw_grid()
        self.current_block.draw()
        self.draw_score()
        if self.level_goal:
            self.draw_level_goal()
        pygame.display.flip()

    def draw_score(self):
        score_text = font.render(f"Score: {self.score}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

    def draw_level_goal(self):
        level_text = font.render(f"Goal: {self.level_goal}", True, (255, 255, 255))
        screen.blit(level_text, (10, 40))


def level_selection():
    level1_button = Button(WIDTH // 2 - 75, HEIGHT // 2 - 100, 150, 50, "Уровень 1", (0, 128, 0), (0, 255, 0),
                           radius=15)
    level2_button = Button(WIDTH // 2 - 75, HEIGHT // 2 - 20, 150, 50, "Уровень 2", (128, 0, 0), (255, 0, 0), radius=15)
    level3_button = Button(WIDTH // 2 - 75, HEIGHT // 2 + 60, 150, 50, "Уровень 3", (0, 0, 128), (0, 0, 255), radius=15)
    free_mode_button = Button(WIDTH // 2 - 100, HEIGHT // 2 + 140, 200, 50, "Свободный режим", (128, 128, 0),
                              (255, 255, 0), radius=15)

    while True:
        screen.blit(background, (0, 0))
        draw_background_pattern()
        level1_button.draw(screen)
        level2_button.draw(screen)
        level3_button.draw(screen)
        free_mode_button.draw(screen)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.MOUSEMOTION:
                mouse_pos = pygame.mouse.get_pos()
                level1_button.check_hover(mouse_pos)
                level2_button.check_hover(mouse_pos)
                level3_button.check_hover(mouse_pos)
                free_mode_button.check_hover(mouse_pos)
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if level1_button.is_clicked(mouse_pos):
                    return 1
                if level2_button.is_clicked(mouse_pos):
                    return 2
                if level3_button.is_clicked(mouse_pos):
                    return 3
                if free_mode_button.is_clicked(mouse_pos):
                    return None


def main():
    create_database()
    player_name = get_player_name()
    if not player_name:
        return

    while True:
        choice = main_menu()
        if choice == "start":
            level = level_selection()
            game = Tetris(level)
            pygame.mixer.music.play(-1)
            while game.running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        game.running = False

                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_LEFT:
                            game.current_block.move(-1, 0)
                            if not game.is_valid_position(game.current_block):
                                game.current_block.move(1, 0)
                        if event.key == pygame.K_RIGHT:
                            game.current_block.move(1, 0)
                            if not game.is_valid_position(game.current_block):
                                game.current_block.move(-1, 0)
                        if event.key == pygame.K_DOWN:
                            game.current_block.move(0, 1)
                            if not game.is_valid_position(game.current_block):
                                game.current_block.move(0, -1)
                        if event.key == pygame.K_UP:
                            game.current_block.rotate()
                            if not game.is_valid_position(game.current_block):
                                game.current_block.rotate()

                game.update()
                game.draw()
                clock.tick(30)

                if game.level_goal and game.score >= game.level_goal:
                    game.running = False
                    screen.fill((0, 0, 0))
                    draw_background_pattern()
                    text_surface = font.render("Уровень пройден!", True, (255, 255, 255))
                    screen.blit(text_surface, (10, HEIGHT // 2))
                    pygame.display.flip()
                    pygame.time.wait(2000)

            if not game.level_goal:
                save_record(player_name, game.score)

            pygame.mixer.music.stop()


if __name__ == "__main__":
    main()
